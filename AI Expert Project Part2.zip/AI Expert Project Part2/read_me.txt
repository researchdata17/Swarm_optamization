---Project AI Expert PSO MATLAB-VREP
Steps of Implementation---Shortest Path Planning Using Particle Swarm Optimization
---Open pso.m in MATLAB and at the same time Open Scene in V-rep from this directory: src-vrep/epuck-dyn-obs-tar.ttt
---Now Run pso.m file in MATLAB.


This will:
-Initialize Map (Goal Point, Obstacles, Start Point, Number of Points and other Parameters)
-Instantiate Model
-Display The Trajectory as well as The Iteration vs Cost Graph using Plot Function.
-Simulation will start leading from start point to goal point
