% Project AI Expert Matlab-Vrep

% This Function is used to initialize the Robot Position, Goal Position and Obstacles as well as
% Grid Size along with other parameters.
function model=CreateModel()

    % Current Robot Position i.e., Source Position
    xs=0;
    ys=0;
    
    % Robot's Target Position i.e., (Destination)
    xt=10;
    yt=10;
    
    x_pos=0
    y_pos=0
    dim=[x_pos, y_pos]
%     Five Obstacles, can be changed by User
    xobs=[2 8];         %Obstacles X Coordinates
    yobs=[2 8];         %Obstacles Y Coordinates
    
    robs=[0.6 0.61];         %Describes the Spread of Obstacles
    
    n=3;
    
    
%     Grid Paramters Initialization

    xmax= 100;               %Maximum Horizontal Grid Size
    xmin=-xmax;             %Maximum Horizontal Grid Size
    
    ymax= 100;               %Maximum Vertical Grid Size
    ymin=-ymax;               %Minimum Vertical Grid Size

%   Now, We Initialize and assign the model objects
    model.xs=xs;
    model.ys=ys;
    model.xt=xt;
    model.yt=yt;
    model.xobs=xobs;
    model.yobs=yobs;
    model.robs=robs;
    model.n=n;
    model.xmin=xmin;
    model.xmax=xmax;
    model.ymin=ymin;
    model.ymax=ymax;
end

% End Here----------------------------------------------------------
