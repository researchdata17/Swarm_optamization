% Project AI Expert Matlab-Vrep
% This Function Calculates the Cost of Function (called my function) and
% returns the parameters.
function [z, sol]=MyCost(sol1,model)

    sol=ParseSolution(sol1,model);
    
    beta=100;
    z=sol.L*(1+beta*sol.Violation);

end

% End Here-------------------------------------------------
