% Project AI Expert Matlab-Vrep
% This Function is built for Creating Random Solution of the Given
% Environment (Model)
function sol1=CreateRandomSolution(model)
% Initialization of Model for n
    n=model.n;
    
    xmin=model.xmin;
    xmax=model.xmax;
    
    ymin=model.ymin;
    ymax=model.ymax;
% Assigning the random solution
    sol1.x=unifrnd(xmin,xmax,1,n);
    sol1.y=unifrnd(ymin,ymax,1,n);
    
end

% End Here----------------------------------------------------------
